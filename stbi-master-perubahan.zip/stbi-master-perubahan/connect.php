<?php
$host='sql303.epizy.com';
$user='epiz_26789813';
$pass='Mi11uQrGLV';
$database='epiz_26789813_stbi';

$conn=mysql_connect($host,$user,$pass);
mysql_select_db($database);

?>